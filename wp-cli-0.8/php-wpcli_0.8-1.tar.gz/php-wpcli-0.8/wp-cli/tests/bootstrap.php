<?php

require_once getcwd() . '/php/utils.php';

require_once __DIR__ . '/abstract-spec.php';
require_once __DIR__ . '/command-runner.php';

