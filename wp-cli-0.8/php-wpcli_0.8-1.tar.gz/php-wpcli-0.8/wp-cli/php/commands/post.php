<?php

/**
 * Manage posts.
 *
 * @package wp-cli
 */
class Post_Command extends \WP_CLI\CommandWithDBObject {

	protected $obj_type = 'post';

	/**
	 * Create a post.
	 *
	 * @synopsis --<field>=<value> [--porcelain]
	 */
	public function create( $_, $assoc_args ) {
		parent::create( $assoc_args );
	}

	protected function _create( $params ) {
		return wp_insert_post( $params, true );
	}

	/**
	 * Update one or more posts.
	 *
	 * @synopsis <id>... --<field>=<value>
	 */
	public function update( $args, $assoc_args ) {
		parent::update( $args, $assoc_args );
	}

	protected function _update( $params ) {
		return wp_update_post( $params, true );
	}

	/**
	 * Delete a post by ID.
	 *
	 * @synopsis <id>... [--force]
	 */
	public function delete( $args, $assoc_args ) {
		$assoc_args = wp_parse_args( $assoc_args, array(
			'force' => false
		) );

		parent::delete( $args, $assoc_args );
	}

	protected function _delete( $post_id, $assoc_args ) {
		$r = wp_delete_post( $post_id, $assoc_args['force'] );

		if ( $r ) {
			$action = $assoc_args['force'] ? 'Deleted' : 'Trashed';

			return array( 'success', "$action post $post_id." );
		} else {
			return array( 'error', "Failed deleting post $post_id." );
		}
	}

	/**
	 * Get a list of posts.
	 *
	 * @subcommand list
	 * @synopsis [--<field>=<value>] [--ids]
	 */
	public function _list( $_, $assoc_args ) {
		$query_args = array(
			'posts_per_page' => -1
		);

		foreach ( $assoc_args as $key => $value ) {
			if ( true === $value )
				continue;

			$query_args[ $key ] = $value;
		}

		if ( isset( $assoc_args['ids'] ) )
			$query_args['fields'] = 'ids';

		$query = new WP_Query( $query_args );

		if ( isset( $assoc_args['ids'] ) ) {
			WP_CLI::out( implode( ' ', $query->posts ) );
		} else {
			$fields = array( 'ID', 'post_title', 'post_name', 'post_date' );

			$table = new \cli\Table();

			$table->setHeaders( $fields );

			foreach ( $query->posts as $post ) {
				$line = array();

				foreach ( $fields as $field ) {
					$line[] = $post->$field;
				}

				$table->addRow( $line );
			}

			$table->display();
		}
	}

	/**
	 * Generate some posts.
	 *
	 * @synopsis [--count=100] [--post_type=<type>] [--post_status=<status>] [--post_author=<login>] [--post_date=<yyyy-mm-dd>] [--max_depth=1]
	 */
	public function generate( $args, $assoc_args ) {
		global $wpdb;

		$defaults = array(
			'count' => 100,
			'max_depth' => 1,
			'post_type' => 'post',
			'post_status' => 'publish',
			'post_author' => false,
			'post_date' => current_time( 'mysql' ),
		);

		extract( wp_parse_args( $assoc_args, $defaults ), EXTR_SKIP );

		if ( !post_type_exists( $post_type ) ) {
			WP_CLI::error( sprintf( "'%s' is not a registered post type.", $post_type ) );
		}

		if ( $post_author ) {
			$post_author = get_user_by( 'login', $post_author );

			if ( $post_author )
				$post_author = $post_author->ID;
		}

		// Get the total number of posts
		$total = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $wpdb->posts WHERE post_type = %s", $post_type ) );

		$label = get_post_type_object( $post_type )->labels->singular_name;

		$hierarchical = get_post_type_object( $post_type )->hierarchical;

		$limit = $count + $total;

		$notify = new \cli\progress\Bar( 'Generating posts', $count );

		$current_depth = 1;
		$current_parent = 0;

		for ( $i = $total; $i < $limit; $i++ ) {

			if ( $hierarchical ) {

				if( $this->maybe_make_child() && $current_depth < $max_depth ) {

					$current_parent = $post_ids[$i-1];
					$current_depth++;

				} else if( $this->maybe_reset_depth() ) {

					$current_depth = 1;
					$current_parent = 0;

				}
			}

			$args = array(
				'post_type' => $post_type,
				'post_title' =>  "$label $i",
				'post_status' => $post_status,
				'post_author' => $post_author,
				'post_parent' => $current_parent,
				'post_name' => "post-$i",
				'post_date' => $post_date,
			);

			wp_insert_post( $args, true );

			$notify->tick();
		}

		$notify->finish();
	}

	private function maybe_make_child() {
		// 50% chance of making child post
		return ( mt_rand(1, 2) == 1 );
	}

	private function maybe_reset_depth() {
		// 10% chance of reseting to root depth
		return ( mt_rand(1, 10) == 7 );
	}
}

WP_CLI::add_command( 'post', 'Post_Command' );

