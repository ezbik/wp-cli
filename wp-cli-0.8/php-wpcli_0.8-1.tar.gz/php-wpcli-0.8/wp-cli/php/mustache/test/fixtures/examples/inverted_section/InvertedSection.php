<?php

class InvertedSection
{
    public $repo = array();
}
