<?php

class InvertedDoubleSection
{
    public $t = false;
    public $two = 'second';
}
