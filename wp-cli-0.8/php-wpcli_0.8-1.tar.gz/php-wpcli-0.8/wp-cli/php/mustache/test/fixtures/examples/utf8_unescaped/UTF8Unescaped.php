<?php

class UTF8Unescaped
{
    public $test = '中文又来啦';
}
