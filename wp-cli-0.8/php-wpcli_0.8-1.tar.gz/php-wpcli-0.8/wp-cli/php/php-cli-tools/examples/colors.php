<?php

require_once 'common.php';


\cli\line('  %C%5All output is run through %Y%6\cli\Colors::colorize%C%5 before display%n');
